let arr=[1,2,3,4,5,6]
let arr1=[];
function even(arr)
{
    for(let k of arr)
    {
        if(k%2!=0)
        {
            arr1.push(k);
        }
    }
}
even(arr);
console.log(arr1)