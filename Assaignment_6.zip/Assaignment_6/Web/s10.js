const arr=[1,2,3,4,5];
const arr1=arr.map((n)=>n*n)
console.log(arr1);