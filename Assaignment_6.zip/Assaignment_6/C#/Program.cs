﻿namespace Assesment_6
{
    internal class Program
    {
        public static void sum(int [] arr)
        {
            int total = 0;
            foreach (int i in arr)
            {
                total = total + i;
            }
            Console.WriteLine(total);
        }
        public static void avg(int[] arr)
        {
            int total = 0;
            foreach (int i in arr)
            {
                total = total + i;
            }
            int avg = total / arr.Length;
            Console.WriteLine(avg);
        }
        public static void sort(int[] arr)
        {
            Array.Sort(arr);
            int max = arr[arr.Length - 1];
            int min = arr[0];
            Console.WriteLine("max value is "+max+" min value is "+min);
        }

        static void Main(string[] args)
        {
            int[] arr = {1,2,3,4,5,6};
            sum(arr);   
            avg(arr);
            sort(arr);
            
        }
    }
}
